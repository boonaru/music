/*global music, Backbone*/

music.Models = music.Models || {};

(function () {
    'use strict';

    music.Models.SongsModel = Backbone.Model.extend({
      parse: function(model) {
        return model.data;
      }
    });

})();
