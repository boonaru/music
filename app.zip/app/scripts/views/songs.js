/*global music, Backbone, JST*/

music.Views = music.Views || {};

(function () {
    'use strict';

    music.Views.SongsView = Backbone.View.extend({
        template: JST['app/scripts/templates/songs.ejs'],
        initialize: function() {
          //this.render();
        },
        render: function() {
          return this.$el.html(this.template);
        },
        tagName: 'ul',
        page: 0,
        count: 25
    });

})();
