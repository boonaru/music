/*global music, $*/


window.music = {
    Models: {},
    Collections: {},
    Views: {},
    Routers: {},
    init: function () {
        'use strict';
        console.log('Hello from Backbone!');

        var layout = new Backbone.Layout({
            el: '#main'
        });

        var songsview = new this.Views.SongsView();

        var songs = new this.Collections.SongsCollection();
        songs.fetch({
            success: function(collection, response, options) {
                songsview.render();
            }
        });
        songs.on('add', function(m) {
            songsview.insertView(new this.Views.SongView({ model: m }));
        }, this);

        new Backbone.Router({
            routes: {
                '': function() {
                    layout.setViews({
                        '.songs': songsview
                    });
                }
            }
        });

        Backbone.history.start();
    }
};

$(document).ready(function () {
    'use strict';
    Backbone.Layout.configure({
        manage: true
    });
    music.init();
});
